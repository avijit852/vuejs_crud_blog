<?php
include './config.php';

//This is header 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");


$methods = $_SERVER['REQUEST_METHOD'];

if($methods == 'POST'){
    //this is post data
    //$action = isset($_POST['action']) ? $_POST['action']:"";
    $bodyParams = json_decode(file_get_contents("php://input"), true);
     // print_r($bodyParams);die;
    $action = $bodyParams['action'];
    if($action == 'insert'){
    
        $name = isset($bodyParams['name']) ? $bodyParams['name'] : "";
        $email = isset($bodyParams['email']) ? $bodyParams['email'] : "";
        $ph = isset($bodyParams['ph']) ? $bodyParams['ph'] : "";

        $insertQry = "Insert into students (`name`,`email`,`ph`) values ('".$name."','".$email."','".$ph."')";

        if( $connection->query($insertQry)===TRUE ){
            echo json_encode(array(
                "status"=>1,
                "msg"=>"value has been inserted",
            ));
        }else {
            echo json_encode(array(
                "status"=>0,
                "msg"=>"Failed to insert value ",
            ));
        }
    }else if($action == "update"){

        $id = isset($bodyParams['id']) ? intval($bodyParams['id']) : "";
        $name = isset($bodyParams['name']) ? $bodyParams['name'] : "";
        $email = isset($bodyParams['email']) ? $bodyParams['email'] : "";
        $ph = isset($bodyParams['ph']) ? $bodyParams['ph'] : "";

        $updateQry = "UPDATE students SET name='".$name."', email='".$email."', ph='".$ph."' WHERE id='".$id."'";

        if($connection->query($updateQry)===TRUE){
            echo json_encode(array(
                "status"=>1,
                "msg"=>"value has been updated",
            ));
        }else{
            echo json_encode(array(
                "status"=>0,
                "msg"=>"failed to update",
            ));
        }
    }

}else if($methods == 'GET'){
    //this is post data
     $action = isset($_GET['action']) ? $_GET['action']:"";

    // $bodyParams = json_decode(file_get_contents("php://input"), true);

    if($action == "list"){
        //this is to get the data
        $id = isset($_GET['id']) ? intval($_GET['id']) : "";

        if(!empty($id)){
            $showQry = "SELECT * from students where id='".$id."'";
        }else{
            $showQry = "SELECT * from students";
        }
       
        $result = $connection->query($showQry);
        
        if($result->num_rows > 0){
           $row_data = array();
           while($row = $result->fetch_assoc()){
               $row_data[] = $row;
           }

        echo json_encode(array(
        "status"=>1,
        "msg"=>"Data found",
        "records"=> $row_data
        ));


        }else{
            echo json_encode(array(
                "status"=>0,
                "msg"=>"No Data found",
            ));
        }

    }else if($action == "delete"){
        //this is to delete the data
        $id = isset($_GET['id']) ? intval($_GET['id']) : "";
        if(!empty($id)){

             $deleteQry = "DELETE FROM students WHERE id = ".$id;
             if( $connection->query($deleteQry)===TRUE ){
                echo json_encode(array(
                    "status"=>1,
                    "msg"=>"record delete successfully",
                ));
            }else{
                echo json_encode(array(
                    "status"=>0,
                    "msg"=>"Faild to delete",
                ));
            }

        }else{
            echo json_encode(array(
                "status"=>0,
                "msg"=>"ID is need",
            ));
        }
    }
}

?>