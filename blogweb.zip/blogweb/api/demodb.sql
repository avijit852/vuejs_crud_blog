-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2020 at 05:16 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `phone`, `address`, `city`, `state`, `zip`) VALUES
(1, 'Avijit Das', 'avijitd852@gmail.com', '9878485795', 'kakdwip', 'kolkata', 'Bihar', '743347'),
(2, 'Rajesh Das', 'rajesh@gmail.com', '9875485968', 'raja bazar', 'patna', 'Bihar', '743359'),
(3, 'Avijit Das', 'avi@gmail.com', '9878485962', 'malchol', 'himchal', 'Haryana', '768948'),
(4, 'Rohit Barma', 'robarma@gmail.com', '98748596', '24 bus stop, near by patuli', 'Madurai', 'Manipur', '764590'),
(5, 'raju nath', 'rnth@gmail.com', '89784825', '60 bp road ', 'kolkata', 'Goa', '898515'),
(6, 'tanu ruchi', 'tanru@gmail.com', '9874859515', '22/48,em bypass', 'Kolkata', 'Gujarat', '700007');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `ph` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `email`, `ph`) VALUES
(1, 'avijit', 'avi@gmail.com', '4589758648'),
(2, 'avijit', 'demo@gmail.com', '9878488568'),
(3, 'sanurita', 'sanurita@gmail.com', '8975864895'),
(4, 'rohit', 'demo@gmail.com', '8975848625'),
(5, 'demo', 'demo@gmail.com', '9878485896'),
(6, 'demo', 'demo@gmail..com', '9875864895'),
(7, 'asv', 'as@gmail.com', '1258974895'),
(8, 'subir', 'subir@gmail.com', '123558984'),
(9, 'demo', 'demo@gmail.com', '5898784866'),
(10, 'avi', 'avijit@gmail.com', '9875864895'),
(11, 'asfc', 'asd@gmail.com', '9875848625'),
(12, 'kali', 'kali@gmail.com', '569494945543'),
(13, 'avi', 'avi@gmail.com', '9875848956'),
(14, 'avjitt', 'avijit@gmail.com', '9875848957'),
(15, 'sc', 'sac@gmail.com', '9875848959'),
(16, 'xf', 'xfb@gmail.com', '9874895865'),
(17, 'avi', 'avi@gmail.com', '9878485969'),
(18, '', '', ''),
(19, 'sas', 'sas@gmail.com', '9878489585'),
(20, 'dv', 'sd@gmail.com', '9878489575'),
(21, 'scs', 'csac@gmail.com', '9874859685'),
(22, 'demo', 'demo@gmail.com', '98748596'),
(23, 'sdfc', 'sdf@gmail.com', '987485965'),
(24, 'dsf', 'sdf@gmail.com', '94466441161'),
(25, 'de', 'de@gmail.com', '9874859658'),
(26, 'demo demo', 'demo@gmail.com', '9874859875'),
(27, 'demo ', 'demo@gmail.com', '9874859875'),
(28, 'sd', 'sd@gmail.com', '9874859685'),
(29, 'demo', 'demo@gmail.com', '9874859685'),
(30, 'sdcfs', 'sdcsd@gmail.com', '99415565'),
(31, 'avi', 'avijit@gmail.com', '98748596'),
(32, 'demo', 'demo@gmail.com', '98475896'),
(33, 'ex', 'ex@gamil.com', '8967489586'),
(34, 'Raju', 'raju@gmail.com', '9874586985'),
(35, 'demo', 'deo@gmail.com', '123589647'),
(36, 'dmeo', 'demo@gmal.com', '12587887'),
(37, 'sdjc', '', ''),
(38, 'xcfvfv', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
