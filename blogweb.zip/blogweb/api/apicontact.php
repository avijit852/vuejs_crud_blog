<?php
include './config.php';

//This is header 
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");


$methods = $_SERVER['REQUEST_METHOD'];

if($methods == 'POST'){
    //this is post data
    //$action = isset($_POST['action']) ? $_POST['action']:"";
    $bodyParams = json_decode(file_get_contents("php://input"), true);
     // print_r($bodyParams);die;
    $action = $bodyParams['action'];
    if($action == 'insert'){
    
        $name = isset($bodyParams['name']) ? $bodyParams['name'] : "";
        $email = isset($bodyParams['email']) ? $bodyParams['email'] : "";
        $phone = isset($bodyParams['phone']) ? $bodyParams['phone'] : "";
        $address = isset($bodyParams['address']) ? $bodyParams['address'] : "";
        $city = isset($bodyParams['city']) ? $bodyParams['city'] : "";
        $state = isset($bodyParams['state']) ? $bodyParams['state'] : "";
        $zip = isset($bodyParams['zip']) ? $bodyParams['zip'] : "";

        $insertQry = "Insert into contact (`name`,`email`,`phone`,`address`,`city`,`state`,`zip`) 
        values ('".$name."',
                '".$email."',
                '".$phone."',
                '".$address."',
                '".$city."',
                '".$state."',
                '".$zip."'
                )";

        if( $connection->query($insertQry)===TRUE ){
            echo json_encode(array(
                "status"=>1,
                "msg"=>"Value has been inserted",
            ));
        }else {
            echo json_encode(array(
                "status"=>0,
                "msg"=>"Failed to insert value ",
            ));
        }
    }else if($action == "update"){
        // print_r($bodyParams);die;
        $id = isset($bodyParams['id']) ? intval($bodyParams['id']) : "";
        $name = isset($bodyParams['name']) ? $bodyParams['name'] : "";
        $email = isset($bodyParams['email']) ? $bodyParams['email'] : "";
        $phone = isset($bodyParams['phone']) ? $bodyParams['phone'] : "";
        $address = isset($bodyParams['address']) ? $bodyParams['address'] : "";
        $city = isset($bodyParams['city']) ? $bodyParams['city'] : "";
        $state = isset($bodyParams['state']) ? $bodyParams['state'] : "";
        $zip = isset($bodyParams['zip']) ? $bodyParams['zip'] : "";

        $updateQry = "UPDATE contact SET 
                    name='".$name."', 
                    email='".$email."', 
                    phone='".$phone."', 
                    address='".$address."', 
                    city='".$city."',
                    state='".$state."', 
                    zip='".$zip."'

                    WHERE id='".$id."'";

        if($connection->query($updateQry)===TRUE){
            echo json_encode(array(
                "status"=>1,
                "msg"=>"value has been updated",
            ));
        }else{
            echo json_encode(array(
                "status"=>0,
                "msg"=>"failed to update",
            ));
        }
    }

}else if($methods == 'GET'){
    //this is post data
     $action = isset($_GET['action']) ? $_GET['action']:"";

    // $bodyParams = json_decode(file_get_contents("php://input"), true);

    if($action == "list"){
        //this is to get the data
        $id = isset($_GET['id']) ? intval($_GET['id']) : "";

        if(!empty($id)){
            $showQry = "SELECT * from contact where id='".$id."'";
        }else{
            $showQry = "SELECT * from contact";
        }
       
        $result = $connection->query($showQry);
        
        if($result->num_rows > 0){
           $row_data = array();
           while($row = $result->fetch_assoc()){
               $row_data[] = $row;
           }

        echo json_encode(array(
        "status"=>1,
        "msg"=>"Data found",
        "records"=> $row_data
        ));


        }else{
            echo json_encode(array(
                "status"=>0,
                "msg"=>"No Data found",
            ));
        }

    }else if($action == "delete"){
        //this is to delete the data
        $id = isset($_GET['id']) ? intval($_GET['id']) : "";
        if(!empty($id)){

             $deleteQry = "DELETE FROM contact WHERE id = ".$id;
             if( $connection->query($deleteQry)===TRUE ){
                echo json_encode(array(
                    "status"=>1,
                    "msg"=>"record delete successfully",
                ));
            }else{
                echo json_encode(array(
                    "status"=>0,
                    "msg"=>"Faild to delete",
                ));
            }

        }else{
            echo json_encode(array(
                "status"=>0,
                "msg"=>"ID is need",
            ));
        }
    }
}

?>