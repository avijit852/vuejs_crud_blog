import Vue from 'vue'
import App from './App.vue'

import { BootstrapVue, BootstrapVueIcons } from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'

import vueResource from 'vue-resource'
import VueRouter from 'vue-router'

import Routes from './route'


//use vue-resource 
Vue.use(vueResource);


//Start Router codeing
Vue.use(VueRouter);
const router = new VueRouter({
  routes:Routes,
  mode:"history"
});
//End 


//use bootstrap and VueIcons
Vue.use(BootstrapVue)
Vue.use(BootstrapVueIcons)

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App),
}).$mount('#app')
