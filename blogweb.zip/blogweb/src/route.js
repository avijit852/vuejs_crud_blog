import Home from './components/Home'
import About from './components/About'
import Gallery from './components/Gallery'
import Contact from './components/Contact'
import AdminList from './components/AdminList'
import ContactUpdate from './components/ContactUpdate'

//router path
export default [
    { path:'/', component:Home },
    { path:'/about', component:About },
    { path:'/gallery', component:Gallery },
    { path:'/contact', component:Contact },
    { path:'/admin', component:AdminList },
    { path:'/contactup/:id', component:ContactUpdate },
];
  