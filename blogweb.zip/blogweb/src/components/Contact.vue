<template>
    <div>
        <div>
            <div class="col-sm-12" :style="{ backgroundImage: 'url(' + image + ')' }" style="background-size: cover;">
            <h2 style="text-align:center;padding:45px;margin:0px">To Contact Information</h2><br>
            </div>
        </div>
        <div class="container">
        
        
        <div style="margin:100px 0px">
            <div class="alert alert-primary " role="alert">
                <h3 style="text-align:center">INSERT YOUR FORM</h3>
                <p style="text-align:center">{{res.msg}}</p>
            </div>
            <form>
            <div class="form-row">
                <div class="form-group col-md-6">
                <label for="inputNAme">Name</label>
                <input type="text" class="form-control" id="inputNAme" placeholder="Name" v-model="contact.name">
                </div>
                <div class="form-group col-md-6">
                <label for="inputEmail">Email</label>
                <input type="email" class="form-control" id="inputEmail" placeholder="Email" v-model="contact.email">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="inputPhone">Phone Number</label>
                    <input type="number" class="form-control" id="inputPhone" placeholder="Phone NUmber" v-model="contact.phone">
                </div>
                <div class="form-group col-md-6">
                    <label for="inputAddress">Address </label>
                    <input type="text" class="form-control" id="inputAddress" placeholder="Address..." v-model="contact.address">
                </div>
            </div>
            
            <div class="form-row">
                <div class="form-group col-md-6">
                <label for="inputCity">City</label>
                <input type="text" class="form-control" id="inputCity" v-model="contact.city">
                </div>
                <div class="form-group col-md-4">
                <label for="inputState">State</label>
                <select id="inputState" class="form-control" v-model="contact.state">
                    <option selected>Choose...</option>
                    <option v-for="state in states" :key="state.id">
                        {{state.stateName}}
                    </option>
                </select>
                </div>
                <div class="form-group col-md-2">
                <label for="inputZip">Zip</label>
                <input type="text" class="form-control" id="inputZip" v-model="contact.zip">
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary" @click.prevent="submitData()">Submit</button>
            </form>
        </div>
        
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            image:'img/con1.jpg',
            contact:{
                name:'',
                email:'',
                phone:'',
                address:'',
                city:'',
                state:'',
                zip:''
            },
            states:[
                {id:1,stateName:'Arunachal Pradesh'},
                {id:2,stateName:'Assam'},
                {id:3,stateName:'Bihar'},
                {id:4,stateName:'Chhattisgarh'},
                {id:5,stateName:'Goa'},
                {id:6,stateName:'Gujarat'},
                {id:7,stateName:'Haryana'},
                {id:8,stateName:'Karnataka'},
                {id:9,stateName:'Kerala'},
                {id:10,stateName:'Manipur'},
            ],
            res:{},
        }
    },
    methods:{
        submitData(){
            
            this.$http.post("http://localhost/vueapi/apicontact.php",{
            name:this.contact.name,
            email:this.contact.email,
            phone:this.contact.phone,
            address:this.contact.address,
            city:this.contact.city,
            state:this.contact.state,
            zip:this.contact.zip,
            action:'insert',
            })
            .then( function(responce){
                this.res = responce.data
                console.log("Res : ",responce);
                console.log("data",responce.data);
                console.log(this.res);
            })
            .catch( function(error){
                console.log(error);
            });

            if(this.res){
                setTimeout(() => {
                    this.res = {};
                    }, 3000);
            } 
            this.contact.name='';
            this.contact.email='';
            this.contact.phone='';
            this.contact.address='';
            this.contact.city='';
            this.contact.state='';
            this.contact.zip='';
        }
    }
}
</script>