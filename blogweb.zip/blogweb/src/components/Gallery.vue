<template>
    <div>
        <div>
            <div class="col-sm-12" :style="{ backgroundImage: 'url(' + image + ')' }" style="background-size: cover;">
            <h2 style="text-align:center;padding:42px;margin:0px;color:#f3f3f3">Our Gallery</h2><br>
            </div>
        </div>

        <div class="container">
        <div class="row">
        <div class="col-sm-12" style="margin:80px 0px">
            <h3 style="text-align:center">About Gallery</h3><br>
            <p style="text-align:center">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
            
           </div>
        </div>
        </div>

        <div class="container">
            <div class="card-deck">
            <div class="card">
                <img class="card-img-top sameImgSize" src="img/gall2.jpg" alt="Card image cap">
                <div class="card-body">
                <h5 class="card-title">Goa</h5>
                <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                </div>
            </div>
            <div class="card">
                <img class="card-img-top sameImgSize" src="img/gall3.jpg" alt="Card image cap">
                <div class="card-body">
                <h5 class="card-title">Simla</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                </div>
            </div>
            <div class="card">
                <img class="card-img-top sameImgSize" src="img/gall4.jpg" alt="Card image cap">
                <div class="card-body">
                <h5 class="card-title">Rajastan</h5>
                <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
                <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
                </div>
            </div>
            </div>
        </div>
        <br><br>
    </div>
</template>

<script>
export default {
    data(){
        return{
            image:'img/gall5.jpg',

        }
    }
}
</script>

<style scoped>
.sameImgSize{
    width: 100%;
    height: 200px;
}
</style>