<template>
    <div>
        <div class="container" >
          <div class="top-view">
            <div class="alert alert-primary " role="alert">
                <h3 style="text-align:center">CONTACT LIST VIEW</h3>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Address</th>
                    <th scope="col">City</th>
                    <th scope="col">State</th>
                    <th scope="col">Zip</th>
                    <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="row in data" :key="row.id">
                    <th scope="row">{{row.id}}</th>
                    <td>{{row.name}}</td>
                    <td>{{row.email}}</td>
                    <td>{{row.phone}}</td>
                    <td>{{row.address}}</td>
                    <td>{{row.city}}</td>
                    <td>{{row.state}}</td>
                    <td>{{row.zip}}</td>
                    <td>
                        <span class="btn btn-primary btn-sm actions">
                            <router-link :to="'/contactup/'+row.id" class="actions">Update</router-link>
                        </span>

                        <span class="btn btn-success btn-sm actions">
                            <router-link :to="'/contactview/'+row.id" class="actions">View</router-link>
                        </span>
                    </td>
                    </tr>
                    
                    
                </tbody>
                </table>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data(){
        return{
            data:[]
        }
    },
    methods:{

    },
    created(){

        this.$http.get("http://localhost/vueapi/apicontact.php?action="+'list',{})
            .then( (responce)=>{
                this.data = responce.data.records.slice(0,10)
                console.log("Res : ",this.data);
            })
            .catch( function(error){
                console.log(error);
            });
    }
}
</script>

<style scoped>
.top-view{
    margin: 100px 0px;
}
.actions{
    color:#f3f3f3;
    margin: 0px 5px;    
}
</style>