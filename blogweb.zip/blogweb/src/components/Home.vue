<template>
  <div class="home">
  <div class="slider" v-bind:style="{ backgroundImage: 'url(' + image + ')' }">
    <h4>
      Do you want to travling ? 
    </h4>
  </div>

  <div class="container">
    <div class="row">
      <div class="col-sm-12">
        <h3 style="text-align:center">Why do we use it?</h3><br>
        <p style="text-align:center">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
      </div>
    </div>

    <div class="row" style="margin:50px 0px" >
      <div class="col-sm-6">
          <br><br>
          <img src="img/tajmahal.jpg" alt="" style="width:95%;height:300px">
      </div>
      <div class="col-sm-6">
        <h3>Where does it come from?</h3><br>
        <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>
      </div>
    </div>
  </div>

  </div>
</template>

<script>
export default {
  data(){
    return{
      image : 'img/slider.jpg',
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
.slider{
  display: block;
  width: 100%;
  
}
.slider h4{
  text-align: center;
  color: #f3f3f3;
  font-family: sans-serif;
  padding: 250px 0px;
  text-transform: uppercase;
}
</style>
